# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

#Libraries for items

#datetime to format date
import datetime

import scrapy

#to remove tags from scrapped items
from w3lib.html import remove_tags
from scrapy.loader import ItemLoader
#to process scrapped items
from itemloaders.processors import MapCompose, TakeFirst


#cleans the price that is scrapped
#remove Rs and comma
def remove_rupees(value):
    try:
        value=value.replace("Rs", "")
    except Exception:
        pass

    try:
        value=value.replace(",","")
    except Exception:
        pass

    return value

#strip the string and sends back
def strip_values(value):
    return value.strip()

#remove the extra variables from Ad ID, strip it and convert to integer
def remove_ad(value):
    return int(value.replace("Ad id ","").strip())


#check if featured or not, and give boolean true false to it
def is_featured(value):

    try:
        if value == "Featured":
            value = True
        else:
            value = False
    except Exception:
        value = False
        pass

    return value


#convert description string to unicode
def transfer_unicode(value):
    return value.encode('UTF-8')


#convert date given on olx to date format
def construct_datetime(value):
    #strip it first
    value=value.strip()
    #split using spaces
    duration=value.split(" ")
    #get the week,day,month,year,minute,hour,second variable
    duration_heading=duration[1]

    #check which one it matches to and perform actions accordingly using current date
    if "week" in duration_heading:
        tod = datetime.datetime.now()
        d = datetime.timedelta(weeks=int(duration[0].strip()))
        value = tod - d
    elif "day" in duration_heading:
        tod = datetime.datetime.now()
        d = datetime.timedelta(days=int(duration[0].strip()))
        value = tod - d
    elif "minute" in duration_heading:
        value = datetime.datetime.now()
    elif "hour" in duration_heading:
        value = datetime.datetime.now()
    elif "second" in duration_heading:
        value = datetime.datetime.now()
    elif "month" in duration_heading:
        tod = datetime.datetime.now()
        d = datetime.timedelta(weeks=int(duration[0].strip())*4)
        value = tod - d
    else:
        pass


    #return date in end
    return value.date()



#process the scrapped items
class OlxCaseStudyScrapyItem(scrapy.Item):

    seller_Name = scrapy.Field(input_processor= MapCompose(remove_tags,strip_values),output_processor=TakeFirst())
    ad_Description=scrapy.Field(input_processor= MapCompose(remove_tags,transfer_unicode,strip_values),output_processor=TakeFirst())
    ad_Price=scrapy.Field(input_processor= MapCompose(remove_tags,remove_rupees,strip_values),output_processor=TakeFirst())
    ad_Id=scrapy.Field(input_processor= MapCompose(remove_tags,remove_ad),output_processor=TakeFirst())
    ad_Type = scrapy.Field(input_processor= MapCompose(remove_tags,strip_values),output_processor=TakeFirst())
    ad_Condition = scrapy.Field(input_processor= MapCompose(remove_tags,strip_values),output_processor=TakeFirst())
    ad_Date = scrapy.Field(input_processor=MapCompose(remove_tags, construct_datetime), output_processor=TakeFirst())
    ad_Url = scrapy.Field()
    ad_Featured= scrapy.Field(input_processor=MapCompose(remove_tags,is_featured), output_processor=TakeFirst())
    pass
