
#IMPORTING LIBRARIES


#middleware was not used because after a lot of testing no useragent or proxies were needed to be used

import scrapy

#for items
from ..items import OlxCaseStudyScrapyItem
#to join url
from urllib.parse import urljoin
#to load items
from scrapy.loader import ItemLoader


#Main spider class
class OlxSpider(scrapy.Spider):

    #Setting up the spider class variables
    name = 'olx'

    #url to start with
    start_urls = ['https://www.olx.com.pk/tablets_c1455']

    #2nd page to go to
    page_number=2

    #To store all links of ads
    ads_links=[]

    #variable to store the total entries
    total_entries=0

    #variable to keep count retries if face same number of links on followup pages
    check_status=0

    #allowed domains
    allowed_domains = ['olx.com.pk']


    #Main parse function to start with and scrape all the links of ads from all pages
    def parse(self, response):


        #store all the links of ads from existing page to the list ads_links by using xpath
        for ads in response.xpath('//li[@aria-label="Listing"]'):
            link="https://www.olx.com.pk" + ads.css("a").attrib['href']
            OlxSpider.ads_links.append(link)



        #If on the first page then get the total number of ads that website shows to get esitmate of what pages we should go till
        if OlxSpider.page_number==2:
            totalentries=response.xpath("//div[@class='_76047990']/text()").get()
            totalentries=totalentries.replace(" ads","")
            totalentries=totalentries.replace(",","")
            totalentries=int(totalentries.strip())
            OlxSpider.total_entries=totalentries

            #set current url to none on 1st page
            curr_url="none"
        else:

            #if not 1st page then get the url we are on
            curr_url=response.request.url
            pass




        #construct url of next page we should go to
        next_page="https://www.olx.com.pk/tablets_c1455?page="+str(OlxSpider.page_number)

        #Current status of links we have scrapped from total website has shown
        print("SCRAPPED : ", len(OlxSpider.ads_links),"/",OlxSpider.total_entries)


        #If we are redirected to same initial link and page number is not shown we should add 1 to retry variable
        if curr_url=="https://www.olx.com.pk/tablets_c1455":
            OlxSpider.check_status+=5

        #if retry variable reaches 5 then we should not try more page numbers and start to scrape data
        if OlxSpider.check_status==5:
            ad_links = OlxSpider.ads_links
            #remove duplicates from our list (so we don't waste time in iterating duplicate links)
            ad_links = list(dict.fromkeys(ad_links))
            print("                                    ")
            print("                                    ")
            print("*****************************************************************************")
            print("TOTAL ADS TO SCRAPE: ", len(ad_links))
            print("*****************************************************************************")
            print("")
            print("")

            #Iterate through each link
            for link in ad_links:
                #construct url
                url = urljoin(response.url, link)
                #go to parse_ads and scrape information
                yield scrapy.Request(url, callback=self.parse_ads)

        else:
            #if we reach the total number of ads as estimated by website we should start to scrape otherwise
            #we follow up to he next page
            if len(OlxSpider.ads_links) < OlxSpider.total_entries:
                yield response.follow(next_page, callback=self.parse, dont_filter=True)
            else:
                #doing same as above
                ad_links = OlxSpider.ads_links
                ad_links = list(dict.fromkeys(ad_links))
                print("                                    ")
                print("                                    ")
                print("*****************************************************************************")
                print("TOTAL ADS TO SCRAPE: ", len(ad_links))
                print("*****************************************************************************")
                print("")
                print("")

                for link in ad_links:
                    url = urljoin(response.url, link)
                    yield scrapy.Request(url, callback=self.parse_ads)

        #Incrementing page number
        OlxSpider.page_number+=1

        print("                                    ")
        print("                                    ")
        print("*****************************************************************************")
        print("")
        print("")




    #this is parse function where we scrape individual ad link
    def parse_ads(self,response):


        #make itemloader instance and set the items from item.py and selector as response
        l = ItemLoader(item= OlxCaseStudyScrapyItem(),selector=response)

        #get the seller name using custom make xpath
        seller_Name=response.xpath("//div[@class='_1075545d _6caa7349 _42f36e3b d059c029']/span/text()").get()
        #added to loader by value
        l.add_value('seller_Name',seller_Name)


        #get price using custom made xpath and added to loader using xpath
        l.add_xpath('ad_Price', "//span[@class='_56dab877']")

        # get Id using custom made xpath and added to loader using xpath
        l.add_xpath('ad_Id', "//div[@class='_171225da']")

        # get description using custom made xpath and added to loader using xpath
        l.add_xpath('ad_Description', "//div[@class='_0f86855a']")

        # get feature using custom made xpath and added to loader using xpath
        ad_feature=response.xpath("//span[@class='_8918c0a8 _2e82a662 a695f1e9']/text()").get()
        #none used here because loader was not handling it correctly
        if ad_feature==None:
            ad_feature="No"
        else:
            pass
        l.add_value('ad_Featured', ad_feature)

        # get ad url and added to loader using xpath
        l.add_value('ad_Url',response.request.url)

        # get date using custom made xpath and added to loader using xpath
        overview=response.xpath("//div[@aria-label='Overview']")
        #iterate through all elements of overview as there are 2 tags with same class name
        for search_container in overview.xpath(".//span[@class='_8918c0a8']"):

            #find out date with key text "go" and then put it to loader
            try:
                value_search=search_container.xpath(".//span/text()").get()
                if "ago" in value_search:
                   l.add_value("ad_Date",value_search)
                   break
            except Exception:
                pass


        #Get into the div tag where we have details of ad given
        #Get the class names of each detail to iterate
        for detail in response.xpath("//div[@class='_676a547f']"):

            #get the heading of details and content written with it
            #this is done because there is no specific classname id or aria label given for condition and type
            heading=detail.xpath(".//span[1]/text()").get()
            content=detail.xpath(".//span[2]/text()").get()

            #match condition and load to loader
            if heading=="Condition":

                l.add_value("ad_Condition", content)

            #match type and load to loader
            elif heading=="Type":

                l.add_value("ad_Type", content)
            else:
                pass


        #return items in loader instance to item.py
        yield l.load_item()